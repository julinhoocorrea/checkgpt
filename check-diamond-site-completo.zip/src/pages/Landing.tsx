
import { Card } from '@/components/ui/card';
import { BarChart3, Diamond, Users, CreditCard } from 'lucide-react';

export default function Landing() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 font-sans">
      {/* Sidebar */}
      <aside className="fixed top-0 left-0 w-60 h-full bg-white border-r border-gray-200 p-6 space-y-6 shadow-sm">
        <div className="text-xl font-bold">Check Diamond</div>
        <nav className="space-y-3">
          <a href="#" className="block font-medium text-blue-600">Dashboard</a>
          <a href="#">Revendedores</a>
          <a href="#">Vendas</a>
          <a href="#">Estoque</a>
          <a href="#">Envios</a>
          <a href="#">Pagamentos</a>
          <a href="#">Configurações PIX</a>
          <a href="#">IA Ana</a>
          <a href="#">Relatórios</a>
        </nav>
        <a href="#" className="text-sm text-red-600">Sair</a>
      </aside>

      {/* Main content */}
      <main className="ml-60 p-10 space-y-6">
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <p className="text-sm text-gray-500">Visão geral das métricas de hoje - 02/07/2025</p>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 mt-6">
          <Card className="p-4">
            <p className="text-sm text-gray-500">Receita Bruta</p>
            <h2 className="text-xl font-bold">R$ 40,00</h2>
            <p className="text-xs text-green-600">+12.5% hoje</p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-gray-500">Lucro Líquido</p>
            <h2 className="text-xl font-bold">R$ 6,55</h2>
            <p className="text-xs text-green-600">+8.2%</p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-gray-500">Total de Vendas</p>
            <h2 className="text-xl font-bold">2</h2>
            <p className="text-xs text-green-600">+5.1%</p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-gray-500">Revendedores Ativos</p>
            <h2 className="text-xl font-bold">2</h2>
            <p className="text-xs text-red-600">-2.1%</p>
          </Card>
          <Card className="p-4">
            <p className="text-sm text-gray-500">Lucro Líquido</p>
            <h2 className="text-xl font-bold">R$ 6,55</h2>
          </Card>
        </div>

        <div className="mt-10">
          <h3 className="text-lg font-medium mb-2">Últimos 7 Dias</h3>
          <div className="bg-white border border-gray-200 rounded-md p-6">
            <p className="text-sm mb-2">Evolução de receita, lucro e comissões</p>
            <div className="w-full h-64 bg-gray-100 flex items-center justify-center rounded">
              <p className="text-gray-500">Gráfico: Lucro R$ 3,25 (10/12/2024)</p>
            </div>
          </div>
        </div>

        <div className="mt-10">
          <h3 className="text-lg font-medium mb-2">Integração PIX (Banco Inter)</h3>
          <div className="bg-white border border-gray-200 rounded-md p-6 space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <input type="text" placeholder="Client ID" className="border p-2 rounded w-full" />
              <input type="text" placeholder="Client Secret" className="border p-2 rounded w-full" />
              <input type="text" placeholder="URL Base Produção" className="border p-2 rounded w-full" />
              <input type="text" placeholder="Chave PIX" className="border p-2 rounded w-full" />
              <input type="text" placeholder="Caminho do Certificado (.p12)" className="border p-2 rounded w-full" />
              <input type="text" placeholder="Webhook URL" className="border p-2 rounded w-full" />
              <input type="text" placeholder="Webhook Secret" className="border p-2 rounded w-full" />
            </div>
            <button className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Salvar Configurações</button>
          </div>
        </div>
      </main>
    </div>
  );
}
